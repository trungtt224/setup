$(document)
  .ready(function() {
    $(window).scroll(function() {
        if ($(this).scrollTop() >= 110 && $(window).width() > 767) {
          $('.return-to-top').fadeIn(200);
          $('#geo-header').attr('style', 'position: fixed; top: 0');
        } else {
          $('.return-to-top').fadeOut(200);
          $('#geo-header').removeAttr('style');
        }
    });

    $('.ui.menu a.item')
      .on('click', function() {
        $(this)
          .addClass('active')
          .siblings()
          .removeClass('active')
        ;
      });

    checkbox();
    messageCloseEvent();
    setTimeout(dropdownTransition(), 200);
  });

function enablePopup(selector) {
  $(selector).popup();
}

/**
 * Apply a specific behavior (show/hide/destroy) to a given CSS selector
 * @param  {[type]} selector CSS selector
 * @param  {[type]} behavior Could be show, hide, etc... Please refer to Semantic-UI#popup for more instructions
 */
function popup(selector, behavior) {
  $(selector).popup(behavior || 'show');
}

function enableHTMLPopup(target, option) {
  $(target)
  .popup({
    position: option.position || 'left center',
    title: option.title,
    html: option.content
  });
}

function modal(selector, behavior) {
  $(selector).modal(behavior || 'toggle');
}

function messageCloseEvent() {
  $('.message .close')
    .on('click', function() {
      $(this)
        .closest('.message')
        .transition('fade')
      ;
    })
  ;
}

function checkbox() {
  $('.ui.checkbox')
    .off()
    .checkbox();
}

function dropdownTransition() {
  $('.ui.dropdown')
    .off()
    .dropdown();
}

function datetimeFormat(hightlightCells, roundSecond) {
  formatInputCalendar('.input-datetime', hightlightCells, 'date_time', roundSecond);
}

function dateHourFormat(hightlightCells) {
  formatInputCalendar('.input-date-hour', hightlightCells, 'date_hour');
}

function dateFormat(hightlightCells) {
  formatInputCalendar('.input-date', hightlightCells, 'date');
}

function formatInputCalendar(selector, hightlightCells, formatType, roundSecond) {
  const cal = $(selector || '.input-datetime');
  const formatter = getFormatter(formatType, roundSecond);

  formatter.cell = function (cell, date, cellOptions) {
    const key = `${date.getFullYear()}-${addZeroInFront(date.getMonth() + 1)}-${addZeroInFront(date.getDate())}`;
    if (hightlightCells !== undefined &&
        hightlightCells !== null &&
        hightlightCells[key] !== undefined &&
        cellOptions.mode === 'hour') {

      const hour = addZeroInFront(date.getHours());
      if (hightlightCells[key].includes(`${hour}`)) {
        $(cell).attr('style', 'color: #2c662d !important;');
      }
    }
  };

  cal.off();
  cal.calendar({
    ampm: false,
    monthFirst: false,
    formatter: formatter,
    type: (formatType === 'date') ? 'date' : 'datetime',
    disableMinute: (formatType === 'date_hour'),
    parser: {
      date: function (text, settings) {
        return new Date(text);
      }
    },
    popupOptions: {
      context: 'geo-view'
    }
  });
}

function getFormatter(type, roundSecond) {
  if (type === 'date_time') {
    return datetimeCalendarFormatter(roundSecond);
  }
  if (type === 'date_hour') {
    return dateHourCalendarFormatter();
  }
  if (type === 'date') {
    return dateCalendarFormatter();
  } else {
    return datetimeCalendarFormatter();
  }
}

/**
 * Get datetime formatter
 * @param  {boolean} roundSecond Whether to round the seconds part or not, if true, seconds will always be 00
 * @return {[type]}
 */
function datetimeCalendarFormatter(roundSecond) {
  return {
    datetime: function (date, settings) {
      const day = date.getDate();
      const month = date.getMonth() + 1;
      const year = date.getFullYear();
      const hour = addZeroInFront(date.getHours());
      const minutes = addZeroInFront(date.getMinutes());
      const seconds = (roundSecond) ? '00' : addZeroInFront(date.getSeconds());
      $('.input-datetime input').trigger('change');
      return `${day}-${month}-${year} ${hour}:${minutes}:${seconds}`;
    }
  }
}

function dateHourCalendarFormatter() {
  return {
    datetime: function (date, settings) {
      const day = date.getDate();
      const month = date.getMonth() + 1;
      const year = date.getFullYear();
      const hour = addZeroInFront(date.getHours());
      $('.input-date-hour input').trigger('change');
      return `${day}-${month}-${year} ${hour}:00`;
    }
  }
}

function dateCalendarFormatter() {
  return {
    datetime: function (date, settings) {
      const day = date.getDate();
      const month = date.getMonth() + 1;
      const year = date.getFullYear();
      $('.input-date input').trigger('change');
      return `${day}-${month}-${year}`;
    }
  }
}

/**
 * Add a zero number in front of value if necessary, e.g: 6 -> 06
 * @param  {Number} value
 * @return {string}
 */
function addZeroInFront(value) {
  return (`${value}`.length === 1) ? `0${value}` : value
}

function createTroubleshootView(detail, summary) {
  const viewContainer = $('#geo-json-container');
  const viewDetail = $('#geo-viewer-detail');
  const viewSummary = $('#geo-viewer-summary');
  viewContainer.empty();
  const viewMode = $('#geo-viewer-menu').attr('view-mode');

  if (viewMode === 'detail') {
    viewDetail.addClass('active');
    viewSummary.removeClass('active');
    viewContainer.jsonview(detail);
  } else {
    viewDetail.removeClass('active');
    viewSummary.addClass('active');
    if ($.isEmptyObject(summary)) {
      viewContainer.append( "<p>No result</p>" );
    } else {
      const table = d3.select('#geo-json-container')
        .append('table')
        .attr('class', 'ui very basic selectable table');

      for (const key in summary) {
        if (summary.hasOwnProperty(key)) {
          const tr = table.append('tr').attr('id', key);
          tr.append('td')
                 .attr('class', 'positive')
                 .text(key);
               tr.append('td')
                 .attr('class', 'left aligned')
                 .text(summary[key]);
        }
      }
    }
  }
  sessionStorage.setItem('currentDetail', JSON.stringify(detail));
  sessionStorage.setItem('currentSummary', JSON.stringify(summary));
}

function createTroubleshootFlow(flow) {
  $('#geo-troubleshoot-sequence')
    .empty()
    .text(flow)
    .sequenceDiagram({theme: 'simple', css_class: 'sequence'});
}

function removeTroubleshootFlow() {
  $('#geo-troubleshoot-sequence')
    .empty();
}

function log(content) {
  if (typeof content === 'string') {
    console.log('+++++++++++++++++++++++++ ' + content + ' ++++++++++++++++++++++++++++++++++');
  } else {
    console.log(content);
  }
}

/**
 * Create sticky view for cell_trace JSON viewer
 * @return {[type]} [description]
 */
function cellTracingStickyView() {
  const offset = $('#geo-header').height() || 0;
  const width = $('#geo-troubleshoot-right').width();
    if ($(this).scrollTop() >= offset + 20 && $(window).width() > 767) {
      $('#geo-sticky').attr('style', `position: fixed; top: ${offset}px; width: ${width}px;`);
    } else {
      $('#geo-sticky').removeAttr('style');
    }
}

/**
 * Create a resizeable cell_trace JSON view for details and summary
 */
function resizeableView() {
  const troubleshootRight = $('#geo-troubleshoot-right');
  const troubleshootLeft = $('#geo-troubleshoot-left');
  let resizableInstance = troubleshootRight.resizable('instance');

  if (typeof resizableInstance === 'undefined') {
    const totalWidth = $('#celltrace-view').width();
    const resizeableSnap = Math.floor(totalWidth / 16);
    let originalLeftColumns = 10;
    let originalRightColumns = 6;
    const minLeftColumn = 8;

    troubleshootRight.resizable({
      handles: 'e, w',
      grid: [ resizeableSnap ]
    });

    troubleshootRight.on('resizestop', function(event, ui) {
      const snapCount = Math.floor(ui.position.left / resizeableSnap);
      const currentLeftColumn = originalLeftColumns + snapCount;

      if (currentLeftColumn >= minLeftColumn) {

        originalLeftColumns = currentLeftColumn;
        originalRightColumns = originalRightColumns - snapCount;
        const leftColumnClasses = getClassFromColumnOf(originalLeftColumns);
        const rightColumnClasses = getClassFromColumnOf(originalRightColumns);

        $(this).removeAttr('class');
        $(this).attr('class', `${rightColumnClasses} no-pad-top no-pad-left`);
        $(this).attr('style', 'border-left: 1px solid #ccc');

        troubleshootLeft.removeAttr('class');
        troubleshootLeft.attr('class', `${leftColumnClasses} no-pad-top`);
      } else {
        ui.element.css(ui.originalPosition);
        ui.element.css(ui.originalSize);
        uiAlert('There\'s no space available on the left!');
      }
      setTimeout(() => cellTracingStickyView(), 100);
    });
    troubleshootRight.css('border-left', '1px solid #ccc');
  }
}

function uiAlert(content, time) {
  $.uiAlert({
    textHead: content,
    text: '',
    bgcolor: '#00918d',
    textcolor: '#fff',
    position: 'bottom-right',
    icon: 'warning sign',
    time: time || 2,
  });
}

function getClassFromColumnOf(column) {
  const suffixClasses = ' wide computer sixteen wide mobile column';
  switch (column) {
    case 1:
        return 'one' + suffixClasses;
    case 2:
        return 'two' + suffixClasses;
    case 3:
        return 'three' + suffixClasses;
    case 4:
        return 'four' + suffixClasses;
    case 5:
        return 'five' + suffixClasses;
    case 6:
        return 'six' + suffixClasses;
    case 7:
        return 'seven' + suffixClasses;
    case 8:
        return 'eight' + suffixClasses;
    case 9:
        return 'nine' + suffixClasses;
    case 10:
        return 'ten' + suffixClasses;
    case 11:
        return 'eleven' + suffixClasses;
    case 12:
        return 'twelve' + suffixClasses;
    case 13:
        return 'thirteen' + suffixClasses;
    case 14:
        return 'fourteen' + suffixClasses;
    case 15:
        return 'fifteen' + suffixClasses;
    case 16:
        return 'sixteen' + suffixClasses;
    default:
        return '';
  }
}

function parseTime(timestamp) {
  const date = new Date(timestamp);
  const tzOffset = date.getTimezoneOffset() * 60000;
  const localISOTime = new Date(timestamp - tzOffset).toISOString();
  return localISOTime.split('T')[1].replace('Z', '');
}

/**
 * Draw sequence diagram for 3G & 4G
 * @param  {array} participants participants
 * @param  {array} messages     messages between participants
 */
function drawSequence(participants, messages) {
  removeTroubleshootFlow();

  const XPAD = 100; // Padding from the left
  const YPAD = 20; // Padding from the top
  const VERT_SPACE = 250; // Space between participants

  const PARTICIPANT_WIDTH = 120; // Width of participant
  const PARTICIPANT_HEIGHT = 40; // Height of participant
  const PARTICIPANT_LABEL_X_OFFSET = -20;
  const PARTICIPANT_LABEL_Y_OFFSET = 25;

  const MESSAGE_SPACE = 80;  // Vertical padding between messages
  const MESSAGE_LABEL_X_OFFSET = -110;
  const MESSAGE_LABEL_Y_OFFSET = 70;
  const MESSAGE_ARROW_Y_OFFSET = 80;

  const CANVAS_WIDTH = participants.length * VERT_SPACE;
  const CANVAS_HEIGHT = YPAD + (PARTICIPANT_HEIGHT * 2) + messages.length * MESSAGE_SPACE;

  // Create an svg canvas
  const svg = d3.select("#geo-troubleshoot-sequence")
    .append("svg")
    .attr("width", CANVAS_WIDTH)
    .attr("height", CANVAS_HEIGHT);


  // Draw participant life time (vertical line)
  participants.forEach(function(p, i) {
    svg.append("line")
      .style("stroke", "#888")
      .attr("x1", XPAD + i * VERT_SPACE)
      .attr("y1", YPAD)
      .attr("x2", XPAD + i * VERT_SPACE)
      .attr("y2", YPAD + PARTICIPANT_HEIGHT + messages.length * MESSAGE_SPACE);
  });

  // Draw participants object
  participants.forEach(function(p, i) {
    const x = XPAD + i * VERT_SPACE;
    // Top
    svg.append("g")
      .attr("transform", "translate(" + x + "," + YPAD + ")")
      .attr("class", "first")
      .append("rect")
      .attr({x: -PARTICIPANT_WIDTH / 2, y: 0, width: PARTICIPANT_WIDTH, height: PARTICIPANT_HEIGHT})
      .style("fill", "#00918d");

    // Bottom
    if (messages.length > 10) {
      const BOTTOM_PAD = YPAD + PARTICIPANT_HEIGHT + messages.length * MESSAGE_SPACE;
      svg.append("g")
        .attr("transform", "translate(" + x + "," + BOTTOM_PAD + ")")
        .attr("class", "first")
        .append("rect")
        .attr({x: -PARTICIPANT_WIDTH / 2, y: 0, width: PARTICIPANT_WIDTH, height: PARTICIPANT_HEIGHT})
        .style("fill", "#00918d");
    }
  });

  // Draw participant's label
  participants.forEach(function(p, i) {
    const x = XPAD + i * VERT_SPACE;
    // Top
    svg.append("g")
      .attr("transform", "translate(" + x + "," + YPAD + ")")
      .attr("class", "first")
      .append("text")
      .style("fill", "#fff")
      .text(function (d) { return p; })
      .attr("dx", function () {
        return (p.startsWith('eNB')) ? -48 : PARTICIPANT_LABEL_X_OFFSET - p.length;
      })
      .attr("dy", PARTICIPANT_LABEL_Y_OFFSET);

    // Bottom
    if (messages.length > 10) {
      const BOTTOM_PAD = YPAD + PARTICIPANT_HEIGHT + messages.length * MESSAGE_SPACE;
      svg.append("g")
        .attr("transform", "translate(" + x + "," + BOTTOM_PAD + ")")
        .attr("class", "first")
        .append("text")
        .style("fill", "#fff")
        .text(function (d) { return p; })
        .attr("dx", function() {
          return (p.startsWith('eNB')) ? -48 : PARTICIPANT_LABEL_X_OFFSET - p.length;
        })
        .attr("dy", PARTICIPANT_LABEL_Y_OFFSET);
    }
  });

  // Draw message arrows
  messages.forEach(function(m, i) {
    let y = YPAD + MESSAGE_ARROW_Y_OFFSET + i * MESSAGE_SPACE;
    if (m.selfCall === false) {
      svg.append("line")
        .style("stroke", "black")
        .attr("x1", XPAD + participants.indexOf(m.sender) * VERT_SPACE)
        .attr("y1", y)
        .attr("x2", XPAD + participants.indexOf(m.receiver) * VERT_SPACE)
        .attr("y2", y)
        .attr("marker-end", "url(#end)");
    } else {
      const startX = XPAD + participants.indexOf(m.sender) * VERT_SPACE
      const lineWidth = VERT_SPACE / 10;
      y = y - lineWidth;

      svg.append("line")
        .style("stroke", "black")
        .attr("x1", startX)
        .attr("y1", y)
        .attr("x2", startX + lineWidth)
        .attr("y2", y);

      svg.append("line")
        .style("stroke", "black")
        .attr("x1", startX + lineWidth)
        .attr("y1", y)
        .attr("x2", startX + lineWidth)
        .attr("y2", y + lineWidth);

      svg.append("line")
        .style("stroke", "black")
        .attr("x1", startX + lineWidth)
        .attr("y1", y + lineWidth)
        .attr("x2", startX)
        .attr("y2", y + lineWidth)
        .attr("marker-end", "url(#end)");
    }
  });

  // Draw message timestamps
  messages.forEach(function(m, i) {
    const xPos = XPAD - 50;
    const yPos = YPAD + MESSAGE_LABEL_Y_OFFSET + i * MESSAGE_SPACE;

    svg.append("g")
      .attr("transform", "translate(" + xPos + "," + yPos + ")")
      .attr("class", "first")
      .attr("text-anchor", "middle")
      .append("text")
      .style("font-size", "12px")
      .text(parseTime(m.time));
  });


  // Draw detail messages
  messages.forEach(function(m, i) {
    const vertCount = participants.indexOf(m.receiver) - participants.indexOf(m.sender);
    const xPos = XPAD + MESSAGE_LABEL_X_OFFSET + ((vertCount * VERT_SPACE) / 2) + (participants.indexOf(m.sender) * VERT_SPACE);
    let yPos = YPAD + MESSAGE_LABEL_Y_OFFSET + i * MESSAGE_SPACE;

    const detailMsg = m.event.toUpperCase().replace(/_/g, ' ');
    const id = m.id;
    if (m.selfCall === false) {
      svg.append("g")
        .attr("transform", "translate(" + xPos + "," + yPos + ")")
        .attr("class", "signal")
        .append("text")
        .attr("id", id)
        .attr('type', 'detail')
        .attr("style", "font-size: 10px")
        .text(detailMsg);
    } else {
      if (m.summary.length > 0) {
        yPos = yPos - 10;
      }
      svg.append("g")
        .attr("transform", "translate(" + (xPos + 55 + VERT_SPACE / 3) + "," + yPos + ")")
        .attr("class", "signal")
        .append("text")
        .attr("id", id)
        .attr('type', 'detail')
        .attr("style", "font-size: 10px")
        .text(detailMsg);
    }

  });


  // Draw summary messages
  messages.forEach(function(m, i) {
    const xPos = XPAD + MESSAGE_LABEL_X_OFFSET + (((participants.indexOf(m.receiver) - participants.indexOf(m.sender)) * VERT_SPACE) / 2) + (participants.indexOf(m.sender) * VERT_SPACE);
    const yPos = YPAD + MESSAGE_LABEL_Y_OFFSET + i * MESSAGE_SPACE;
    const id = m.id;
    let summary = m.summary;
    if (m.selfCall === false) {
      svg.append("g")
        .attr("transform", "translate(" + xPos + "," + (yPos + 30) + ")")
        .attr("class", "signal")
        .append("text")
        .attr('id', id)
        .attr('type', 'summary')
        .attr('xml:space', 'preserve')
        .text(summary);
    } else {
      if (summary.length > 0) {
        summary = `(${summary})`;
      }
      svg.append("g")
        .attr("transform", "translate(" + (xPos + 55 + VERT_SPACE / 3) + "," + (yPos + 10) + ")")
        .attr("class", "signal")
        .append("text")
        .attr("id", id)
        .attr('type', 'summary')
        .attr('xml:space', 'preserve')
        .text(summary);
    }
  });

  // Arrow style
  svg.append("svg:defs").selectAll("marker")
      .data(["end"])
      .enter().append("svg:marker")
      .attr("id", String)
      .attr("viewBox", "0 -5 10 10")
      .attr("refX", 10)
      .attr("refY", 0)
      .attr("markerWidth", 10)
      .attr("markerHeight", 10)
      .attr("orient", "auto")
      .append("svg:path")
      .attr("d", "M0,-5L10,0L0,5");
}


function leaflet() {
  return L;
}

function d3js() {
  return d3;
}

function addFullscreenControl(map) {
  const fsControl = new L.Control.FullScreen();
  map.addControl(fsControl);
}

function createNumberedMarker(lat, lng, num, highlight) {
  return new L.Marker(new L.LatLng(lat, lng), {
    icon: new L.NumberedDivIcon({number: `<span style="color:${highlight}; background-color: #e9e97c; font-weight: bold;">(${num})<span>`})
  });
}

function createHighlightIcon() {
  return L.icon({
    iconUrl: 'assets/images/marker-highlight-icon.png'
  });
}

function defaultMarkerIcon() {
  return L.icon({
    iconUrl: 'assets/images/marker-icon.png'
  });
}

function userMarkerIcon() {
  return L.icon({
    iconUrl: 'assets/images/user-marker-icon.png',
    iconSize: [16, 16]
  });
}

const colorHues = ['#cc2812', '#0e911b', '#8223ff', '#3ec9ad', '#db8a64', '#686d01'];
function getRandomColor(hueIndex, count) {
  return randomColor({
   count: count,
   hue: colorHues[hueIndex],
   luminosity: 'dark'
  });
}

function toggleModal(selector, behavior, onHidden, onVisible) {
  $(selector)
    .modal({
      onHidden: onHidden,
      onVisible: onVisible
    })
    .modal(behavior || 'show');
}
